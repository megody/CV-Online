# CV TRADOTTO

A Pen created on CodePen.

Original URL: [https://codepen.io/megody/pen/dPyzvgJ](https://codepen.io/megody/pen/dPyzvgJ).

